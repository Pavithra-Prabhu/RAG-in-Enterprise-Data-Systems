const cards = document.querySelectorAll(".info-card");
const openAllBtn = document.getElementById("openAllBtn");

function openCard(card) {
  const content = card.querySelector(".card-content");
  card.classList.add("active");
  content.style.maxHeight = content.scrollHeight + "px";
}

function closeCard(card) {
  const content = card.querySelector(".card-content");
  card.classList.remove("active");
  content.style.maxHeight = null;
}

cards.forEach((card, index) => {
  const button = card.querySelector(".card-toggle");

  if (index === 0) {
    openCard(card);
  }

  button.addEventListener("click", () => {
    const isActive = card.classList.contains("active");

    cards.forEach((item) => closeCard(item));

    if (!isActive) {
      openCard(card);
    }
  });
});

let expanded = false;

openAllBtn.addEventListener("click", () => {
  if (!expanded) {
    cards.forEach((card) => openCard(card));
    openAllBtn.textContent = "Collapse All";
    expanded = true;
  } else {
    cards.forEach((card, index) => {
      if (index === 0) {
        openCard(card);
      } else {
        closeCard(card);
      }
    });
    openAllBtn.textContent = "Expand All";
    expanded = false;
  }
});

window.addEventListener("resize", () => {
  cards.forEach((card) => {
    if (card.classList.contains("active")) {
      const content = card.querySelector(".card-content");
      content.style.maxHeight = content.scrollHeight + "px";
    }
  });
});